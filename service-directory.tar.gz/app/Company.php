<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Company
 *
 * @package App
 * @property string $name
 * @property string $city
 * @property string $address
 * @property text $description
*/
class Company extends Model
{
    use SoftDeletes;

    protected $fillable = ['name', 'address', 'description', 'city_id'];
    
    

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCityIdAttribute($input)
    {
        $this->attributes['city_id'] = $input ? $input : null;
    }
    
    public function city()
    {
        return $this->belongsTo(City::class, 'city_id')->withTrashed();
    }
    
    public function categories()
    {
        return $this->belongsToMany(Category::class, 'category_company')->withTrashed();
    }
    
}
